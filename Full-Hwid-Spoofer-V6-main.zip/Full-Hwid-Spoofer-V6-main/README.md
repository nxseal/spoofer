## Info 
- Windows Version? Windows 11/10 all version "haven't tried on older windows"
- Does it work with AMD CPU and Motherboard? tested and it works on AMD and INTEL motherboard and CPU.
- Does it require format? No, but you will need to delete the game before starting the spoofer.
- Is it easy? Yes!
- Is it one-click spoof? Yes, the new version of it is a 1click.
- Is it permanent? Yes, even if you formatted your PC, you will be spoofed forever.
- Can I unspoof after spoofing? For unlimited users, Yes, but for the one time use, No.
- How many times can I spoof? Depends on what type of the spoofer did you purchase, if it's Unlimited, then every time you got banned by some reason, just open the spoofer and respoof and the HWID ban will be removed, but if it's one time use, You can only spoof your hardware once but the spoof will be forever!
- Does it works on laptops? DELL AND HP ARE NOT SUPPORTED, for the others, yes.
- Can my PC get bricked using the spoofer? No.
- Will it ever be patched? the Vanguard will see you as you bought a new PC parts, and since it doesn't inject anything to your system or installing driver, you shouldn't be worry about it being patched or getting ban.

### Spoofing
* Regedit Spoofer
* Mac
* Gpu
* Guild
* Bios Spoofer
* Base Board
* Number
* Tracking File
* Temp
* Cache 
* Guild
* Raid 
* Disks
* Network

![](https://i.ibb.co/C8gBv9L/AR22.png)
