#pragma once
#include <Windows.h>
#include <iostream>
#include "encrypt\xor.h"
void CleanCaches();