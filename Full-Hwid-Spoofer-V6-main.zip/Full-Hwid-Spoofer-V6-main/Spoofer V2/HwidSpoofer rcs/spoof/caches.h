#pragma once
#include <Windows.h>
#include <iostream>
#include <sstream>
#include "..\encrypt\xor.h"
void CleanCaches();