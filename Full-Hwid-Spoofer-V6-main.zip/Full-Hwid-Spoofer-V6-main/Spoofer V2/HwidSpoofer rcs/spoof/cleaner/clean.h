#pragma once
#include "stdafx.h"
int CleanProcess();
BOOL cleanProcess;